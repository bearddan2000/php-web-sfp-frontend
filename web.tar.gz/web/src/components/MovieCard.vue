<template lang="pug">
  div.movie-card.tooltip
    img(:src="'https://image.tmdb.org/t/p/w500/' + jsonData.poster_path" alt="poster not found" @click="showModal")
    h3 {{ jsonData.title }}
    h4 Average rating {{ jsonData.vote_average }}
    span.tooltiptext
      p #[b Title]: {{ jsonData.title }}
      p #[b Released]: {{ jsonData.release_date }}
      p #[b Summary]: {{ jsonData.overview }}
    MovieModal(v-show="isModalVisible" @close="closeModal")
      template(v-slot:header)
          p #[b Title]: {{ jsonData.title }}
          p #[b Released]: {{ jsonData.release_date }}
      template(v-slot:body)
          img(:src="'https://image.tmdb.org/t/p/w500/' + jsonData.poster_path" alt="poster not found")
          p #[b Summary]: {{ jsonData.overview }}
      template(v-slot:footer)
          div
            a(v-for="(part, index) in clips" :key="index" :href="'https://www.youtube.com/watch/?v=' + part.id.videoId")
              img(:src="part.snippet.thumbnails.default.url" :width="part.snippet.thumbnails.default.width" :height="part.snippet.thumbnails.default.height")
</template>

<script>
import MovieModal from '@/components/MovieModal.vue'

export default {
  name: 'MovieCard',
  props: {
    jsonData: Object
  },
  components: {
    MovieModal
  },
  data () {
    return {
      isModalVisible: false,
      clips: []
    };
  },
  methods: {
    showModal() {
      this.isModalVisible = true;

          var url="https://www.googleapis.com/youtube/v3/search?";
          url +="part=snippet";
          //url +="&order=viewCount";
          //url +="&forDeveloper=true";
          url +="&q=" + encodeURIComponent(this.jsonData.title);
          url +="&maxResults=3";
          url +="&key=AIzaSyAD5vI1uqgeF_L7Pt29QUYryeovqIWtGJk";

          this.$http.get(url)
           .then((response) => {
              this.clips=response.data.items;
              console.log(response.data.items);
           })
           .catch((error) => {
               console.log(error)
           });
    },
    closeModal() {
      this.isModalVisible = false;
    }
  },
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/_varibles';

.tooltip .tooltiptext {
  visibility: hidden;
  width: 220px;
  background-color: $link-background;
  color: black;
  text-align: center;
  padding: $panel-padding 0;
  border-radius: $panel-border-radius;
  //opacity: 0.4;

  position: absolute;
}

/* Show the tooltip text when you mouse over the tooltip container */
.tooltip:hover .tooltiptext {
  visibility: visible;
}

img {
    width: 125px;
    height:155px;
    &:hover{
      cursor: pointer;
    }
}
</style>
