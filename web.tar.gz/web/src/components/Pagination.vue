<template lang="pug">
  span.pagination
    span.pager(@click="firstPage()", title="Go to first page") First
    span.pager(@click="prevPage()", title="Go to previous page") {{ this.displayLastPage() }}
    span.pager.current(title="Current page") {{ this.displayCurrent() }}
    span.pager(@click="nextPage()", title="Go to next page") {{ this.displayNextPage() }}
    span.pager(@click="lastPage()", title="Go to last page") Last
</template>

<script>
export default {
  name: 'Pagination',
  props: {
    filter: String
  },
  methods: {
    firstPage: function(){
      this.build(1);
    },
    prevPage: function(){
      let currentPage = this.displayLastPage();

      this.build(currentPage);
    },
    nextPage: function(){
      let currentPage = this.displayNextPage();

      this.build(currentPage);
    },
    lastPage: function(){
      this.build(500);
    },
    build: function(currentPage){
    
      let currentUrl = window.location.href;

      let nextUrl = ""; currentUrl.split("/")[0];
      nextUrl += "/" + this.filter.toLowerCase();
      nextUrl += "/" + currentPage;

      this.go(nextUrl);
    },
    go: function(nextUrl){
      window.location.href = nextUrl;
    },
    getPage: function(){ return parseInt(this.$route.params.page);},
    displayLastPage(){
      let currentPage = this.getPage();

      if(currentPage-1 < 1)
        currentPage = 501;

      currentPage--;

      return currentPage;
    },
    displayCurrent: function(){
      return this.getPage();
    },
    displayNextPage(){
      let currentPage = this.getPage();

      if(currentPage+1 > 500)
        currentPage = 0;

      currentPage++;

      return currentPage;
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/scss/_links';

.pager {
  @include panel-decore;
  font-weight: bold;
  font-size: 18px;
  cursor: pointer;
}
.current {
  color: $link-active;
}
</style>
