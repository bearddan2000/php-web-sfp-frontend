<template lang="pug">
  div.genre
    div.wrapper
      div.header Genre {{ filter }} page {{ this.$route.params.page }} of 500 |
        Pagination(:filter="filter")
      div.main
        div.sidebar
          h3 Genre
          div.menu-item(v-for="(item, index) in $store.state.menu" :key="index")
            Menu(:jsonData="item")
        div.box-content
          div.card(v-for="(article,id) in articles" :key="id")
            MovieCard(:jsonData="article")
      div.footer page {{ this.$route.params.page }} of 500 |
        Pagination(:filter="filter")
</template>

<script>
import Menu from '@/components/Menu.vue'
import MovieCard from '@/components/MovieCard.vue'
import Pagination from '@/components/Pagination.vue'

export default {
  name: 'Genre',
  props: {
    genreId: String,
    filter: String
  },
  components: {
    Menu,
    MovieCard,
    Pagination
  },
  data: function(){ return {
    articles: []
    };
  },
  created: function(){
     // ref https://developers.themoviedb.org/3/movies/get-movie-details

      let page = parseInt(this.$route.params.page);

      if(page > 500) page = 1;
      else if(page < 1) page = 500;

      var url="https://api.themoviedb.org/3/discover/movie?api_key=582722d0a309ef5161e3e1b210f55139";

      // filter by language
      url += "&language=en-US";

      // limit results
      url += "&page=" + page;

      // filter by genre
      url += "&with_genres=" + parseInt(this.genreId);

      var authStr = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1ODI3MjJkMGEzMDllZjUxNjFlM2UxYjIxMGY1NTEzOSIsInN1YiI6IjVmMGNiOGEwNDk4ZWY5MDAzMzg2MjI4YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.d9aE6rosbCDfSvLdE4l6tt6Bdk4eE8KrtK6Zzjhk6oI";

      this.$http.get(url, { 'headers': { 'Authorization': authStr } })
     .then((response) => {
         this.articles = response.data.results;
     })
     .catch((error) => {
         console.log(error)
     });
  }
}
</script>
<style lang="scss" scoped>
@import '@/assets/scss/_sidebar';

.wrapper {
  height: 100vh;
  @include grid-align(stretch);
  grid-template-columns: 3fr;
  grid-template-rows: 30px auto 30px;
  grid-template-areas: "header"
                       "main"
                       "footer"
}

.main {
  grid-area: main;
  display: grid;
  grid-template-columns: 105px 1fr;
  grid-template-rows: 1fr;
  grid-template-areas: "sidebar box-content";
}

.box-content {
  grid-area: box-content;
  align-items: start;
  align-content: start;
  display: grid;
  grid-gap: 10px;
  padding: 10px;
  grid-template-columns: repeat(5, 1fr);
}

.header  {
  grid-area: header;
  font-weight: bold;
  font-size: 18px;
  background-color: white;
}

.footer { grid-area: footer; }

.card {
  background-color: $link-active;
}

body {
  padding: 0px;
  margin: 0px;
}

div {
  background-color: $link-background;
  border: 1px solid white;
  border-radius: $panel-border-radius;
}
* {
  box-sizing: border-box;
}
</style>
