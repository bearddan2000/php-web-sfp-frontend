<template>
  <router-link :to="jsonData.link">{{jsonData.name}}</router-link>
</template>

<script>
export default {
  name: 'Menu',
  props: {
    jsonData: Object
  }
}
</script>
