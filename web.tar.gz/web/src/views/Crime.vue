<template>
  <div class="crime">
    <Genre genreId="80" filter="Crime"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'crime',
  components: {
    Genre
  }
}
</script>
