<template>
  <div class="drama">
    <Genre genreId="18" filter="Drama"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'drama',
  components: {
    Genre
  }
}
</script>
