<template>
  <div class="fantasy">
    <Genre genreId="14" filter="Fantasy"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'fantasy',
  components: {
    Genre
  }
}
</script>
