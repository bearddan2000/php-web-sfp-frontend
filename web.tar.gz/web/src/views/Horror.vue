<template>
  <div class="horror">
    <Genre genreId="27" filter="Horror"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'horror',
  components: {
    Genre
  }
}
</script>
