<template lang="pug">
  div.home
    img(alt="Vue logo", src="../assets/logo.png")
    br
    span(v-for="(item,index) in $store.state.menu", :key="index")
      Menu(:jsonData="item") {{getSeperator(index, $store.state.menu)}}
</template>

<script>
// @ is an alias to /src
import Menu from '@/components/Menu.vue'

export default {
  name: 'Home',
  components: {
    Menu
  },
 methods: {
  getSeperator: function(index, menu){
    if(index < menu.length-1) return " |";
    return "";
  }
 }
}
</script>

<style lang="scss" scoped>
  @import '@/assets/scss/_links';
</style>
