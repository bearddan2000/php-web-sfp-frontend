<template>
  <div class="action">
    <Genre genreId="28" filter="Action"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'action',
  components: {
    Genre
  }
}
</script>
