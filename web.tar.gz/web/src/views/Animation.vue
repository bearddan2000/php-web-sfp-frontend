<template>
  <div class="animation">
    <Genre genreId="16" filter="Animation"/>
  </div>
</template>

<script>
import Genre from '@/components/Genre.vue'

export default {
  name: 'animation',
  components: {
    Genre
  }
}
</script>
