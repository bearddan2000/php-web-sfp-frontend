import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export const store = new Vuex.Store({
  state: {
    menu: [
      { "name": "Home", "link": "/" },
      { "name": "Action", "link": "/action/1" },
      { "name": "Animation", "link": "/animation/1" },
      { "name": "Crime", "link": "/crime/1" },
      { "name": "Drama", "link": "/drama/1" },
      { "name": "Fantasy", "link": "/fantasy/1" },
      { "name": "Horror", "link": "/horror/1" }
    ]
  }
});
